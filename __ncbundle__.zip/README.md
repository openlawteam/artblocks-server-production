Art Blocks Server

npm i

make sure and add your rpc provider key in a .env file.

Use Node 10

Replace contract address inside index.js
